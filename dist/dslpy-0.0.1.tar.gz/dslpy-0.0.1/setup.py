from setuptools  import setup
from setuptools import find_packages

setup(
    name= 'dslpy',
    version= '0.0.1',
    packages=find_packages(),
    author='Yuan Shi',
    author_email=' ',
    url = " "
)
